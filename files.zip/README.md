# MiniPlay 🎵

A minimal music player PWA your lil sis can install on her phone.

---

## How to run it

### Option 1 — Easiest: Use VS Code Live Server
1. Open the `music-app` folder in VS Code
2. Install the **Live Server** extension
3. Right-click `index.html` → **Open with Live Server**
4. Open the URL on your phone (must be same Wi-Fi)

### Option 2 — Python (built-in)
```bash
cd music-app
python3 -m http.server 8080
```
Then open `http://localhost:8080` in your browser.

### Option 3 — Deploy free (recommended for phone install)
Upload to **Netlify** (netlify.com) by dragging the `music-app` folder onto their dashboard.
Your sis gets a real URL she can open on her phone and install.

---

## How to install on phone

**Android (Chrome):**
1. Open the app URL in Chrome
2. Tap the menu (⋮) → **Add to Home screen**
3. Or tap the **Install** banner that appears in the app

**iPhone (Safari):**
1. Open the app URL in Safari
2. Tap the Share button → **Add to Home Screen**

---

## Features
- Upload and play mp3 files
- Saves song list between visits
- Play / pause / next / previous
- Progress bar + seek
- Volume control
- Installs on home screen like a real app
- Works offline after first visit

---

## Folder structure
```
music-app/
├── index.html      ← the whole app
├── manifest.json   ← makes it installable
├── sw.js           ← offline support
└── icons/
    ├── icon-192.png
    └── icon-512.png
```
